package com.smiligenceUAT1.metrozadmin.common;

public class CommonDropDown
{
    public static String[] Role_drop_down = {"Select Role Name","Seller", "Delivery Boy", "Third Party"};
    public static String[] category_priority_drop_down = {"Select Category Priority","1", "2", "3"};
}
